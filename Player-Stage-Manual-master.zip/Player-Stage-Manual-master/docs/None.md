[Redirect to documents](http://player-stage-manual.readthedocs.org/en/latest)
